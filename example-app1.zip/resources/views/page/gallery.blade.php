
<body style="background:{{$color}}">

<h1>wel come my gallery</h1>
<hr>

{{--<a href="{{route('pages')}}">home</a><br>--}}
</body>