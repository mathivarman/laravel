<h1>welcome my home page </h1>
<br>
<body style="background:{{$color}}">

{{-- <a href="{{route('pages')}}">home</a><br>
<a href="{{route('pages',['n'=>'gallery','c'=>'red'])}}">my gallery</a><br>
<a href="{{route('pages',['n'=>'myinfo','c'=>'pink'])}}">my info</a><br>
<a href="{{route('pages',['n'=>'aboutus','c'=>'yellow'])}}">about</a><br>
<a href="{{route('pages',['n'=>'video','c'=>'blue'])}}">video</a><br>
<a href="{{route('pages',['n'=>'contactus','c'=>'green'])}}">contactus</a> --}}