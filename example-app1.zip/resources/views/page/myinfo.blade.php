
<body style="background:{{$color}}">

<h1>myinformation</h1>
<hr>

<a href="{{route('pages')}}">home</a><br>
</body>