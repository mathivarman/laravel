<body style="background:
<?php 
    echo $c
?>>"
contactus
<hr>
{{$n}}
<a href="{{route('pages')}}">home<a/>
</body>