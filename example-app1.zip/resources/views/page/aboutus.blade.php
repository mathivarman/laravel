
    aboutus
<body style="background:{{$color}}">
<form action="/postpage" method="post">
 Page Name :   <input type="text" id="pname" name="pname" >
 color :   <input type="text" id="color" name="color" >
 @csrf
 <input type="submit" value="submit">
</form>
