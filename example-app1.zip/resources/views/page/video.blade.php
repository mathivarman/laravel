<h1>video</h1>
<body style="background:{{$color}}">


<hr>
{{-- <a href="{{route('pages')}}">home</a> --}}
</body>