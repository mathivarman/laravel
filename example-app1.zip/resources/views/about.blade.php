<h1>welcome</h1>
<hr>

<hr>
<?php

?>
{{--<a href="{{route('home')}}" > go to welcome pageee </a> -->
<br>
<!-- <a href="/n" > go to welcome page </a> -->--}}
<form action="test" method="post">
@csrf 
<input type="submit">
</form>