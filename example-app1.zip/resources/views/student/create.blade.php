<h1>Create</h1>

@if($errors->any())
  @foreach($errors->all() as $error)
    {{$error}}
  @endforeach
@endif

<form action ="{{route('student.store')}}" method = "POST">

@csrf
<label for="fname">First Name</label>
<input type ="text" name="fname" id="fname">
<br><br>
<label for="lname">Last Name</label>
<input type ="text" name="lname" id="lname">
<br><br>
<label for ="gender">Gender:</label>
<input type="radio" id="male" name="gender" value="male">
<label for="male">Male</label>
<input type="radio" id="female" name="gender" value="female">
<label for="female">Female</label>
<br><br>
<label for="grade">Select Grade</label>
<select name="grade" id="grade">
  <option value="2020">2020</option>
  <option value="2021">2021</option>
  <option value="2022">2022</option>
</select>
<br><br>
<label for="address">Address</label>
<textarea name="address" id="address" cols="30" rows="5"></textarea>
<br><br>
<label for="subject">Subjects</label><br>
<input type="checkbox" id="SFT" name="subject[]" value="SFT">
<label for="SFT"> SFT</label>
<input type="checkbox" id="ET" name="subject[]" value="ET">
<label for="ET"> ET</label>
<input type="checkbox" id="ICT" name="subject[]" value="English">
<label for="ICT"> English</label>
<br><br>
<label for="birthday">Birthday:</label>
<input type="date" id="birthday" name="birthday" >
<br><br>
<label for="email">Enter your email:</label>
<input type="email" id="email" name="email">
<br><br>
<label for="phone">Enter your phone number:</label>
<input type="phone" id="phone" name="phone" >
<br><br>
<input type="submit" value="Save">


</form>

