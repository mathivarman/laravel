<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Studentlist</h1>
    
    <a href="{{route('student.create' )}}">create</a>
    <br><hr>
    {{--@foreach ($students as $student)
    {{$student->id}}
    {{$student->first_name}}
    {{$student->last_name}}
    {{$student->gender}}
    {{$student->grade}}
    {{$student->address}}
    {{$student->subject}}
    {{$student->date_of_birth}}
    {{$student->mail}}
    {{$student->phone}}
    <br>
    @endforeach--}}
    <table border="1">
        <tr><th>ID</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Gender</th></tr>
    @foreach ($students as $student)
    <tr>
    <td> {{$student->id}}</td>
   <td> {{$student->first_name}}</td>
    <td>{{$student->last_name}}</td>
    <td>{{$student->gender}}</td>
    
    <td><a href="{{route('student.show' ,$student->id)}}">Show</a></td>
    <td><a href="{{route('student.edit' ,$student->id)}}">Edit</a></td>
    <td>
        <form action="{{route('student.destroy' ,$student->id)}}" method="POST" >
            @csrf 
            @method('delete')
        <input type="submit" value="Delete">
</form></td>
    </tr>
    @endforeach
    </table>
    <br>
    
    
</body>
</html>

   


