<h1>index </h1>



<table border="1">
@foreach($employe as $em)
<tr><td>{{$em->id}}</td>
<td>{{$em->first_name}}</td>
<td>{{$em->last_name}}</td>
<td>{{$em->DOB}}</td>
</tr>
@endforeach
</table>