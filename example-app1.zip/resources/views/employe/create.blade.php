<h1>create</h1>

<form action="{{route('employe.store')}}" method="POST">
@csrf 
<lable for="fname">first name </lable>
<input type="text" name="fname" id="fname" >
<br>
<lable for="lname">last name </lable>
<input type="text" name="lname" id="lname" >
<br>
<lable for="DOB">dob </lable>
<input type="date" name="DOB" id="DOB" >
<br>
<input type="submit" value="Save">
</form>