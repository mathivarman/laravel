<form action="/test" method="post>

page name <input type="text" id="fname" name="fname">
<br>
colour <input type="text" 