<?php

namespace App\Http\Controllers;



use Illuminate\Http\Request;


class HomeController extends Controller
{
     public function myInfo(){
         return "welcome my controller";}
         public function one(){
            return view('one');}
            public function two(){
                return view('two');}
                public function three(){
                    return view('three');}
                    public function four(){
                        return view('four');}
                        public function five(){
                            return view('five');}
     
}
