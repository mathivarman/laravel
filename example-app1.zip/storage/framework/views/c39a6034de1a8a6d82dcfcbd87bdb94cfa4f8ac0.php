<h1>welcome</h1>
<hr>

<hr>
<?php

?>

<form action="test" method="post">
<?php echo csrf_field(); ?> 
<input type="submit">
</form><?php /**PATH D:\example-app\resources\views/about.blade.php ENDPATH**/ ?>