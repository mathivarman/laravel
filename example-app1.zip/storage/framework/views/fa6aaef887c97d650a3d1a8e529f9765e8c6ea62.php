<h1>video</h1>
<body style="background:<?php echo e($color); ?>">


<hr>

</body><?php /**PATH D:\example-app\resources\views/page/video.blade.php ENDPATH**/ ?>