
    aboutus
<body style="background:<?php echo e($color); ?>">
<form action="/postpage" method="post">
 Page Name :   <input type="text" id="pname" name="pname" >
 color :   <input type="text" id="color" name="color" >
 <?php echo csrf_field(); ?>
 <input type="submit" value="submit">
</form>
<?php /**PATH D:\example-app\resources\views/page/aboutus.blade.php ENDPATH**/ ?>