<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Student Show Details</h1>
    <h3>First Name: <?php echo e($student->first_name); ?></h3>
    <h3>Last Name: <?php echo e($student->last_name); ?></h3>
    <h3>Gender: <?php echo e($student->gender); ?></h3>
    <h3>Grade: <?php echo e($student->grade); ?></h3>
    <h3>Address: <?php echo e($student->address); ?></h3>
    <h3>Subject: <?php echo e($student->subject); ?></h3>
    <h3>Date Of Birth: <?php echo e($student->date_of_birth); ?></h3>
    <h3>Email: <?php echo e($student->mail); ?></h3>
    <h3>Mobile No: <?php echo e($student->phone); ?></h3>
    <br>

    <a href="<?php echo e(route('student.index' )); ?>">show student list</a>
</body>
</html>
<?php /**PATH D:\example-app\resources\views/student/show.blade.php ENDPATH**/ ?>