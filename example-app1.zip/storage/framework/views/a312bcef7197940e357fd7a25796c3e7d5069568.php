<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Studentlist</h1>
    
    <a href="<?php echo e(route('student.create' )); ?>">create</a>
    <br><hr>
    
    <table border="1">
        <tr><th>ID</th>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Gender</th></tr>
    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
    <td> <?php echo e($student->id); ?></td>
   <td> <?php echo e($student->first_name); ?></td>
    <td><?php echo e($student->last_name); ?></td>
    <td><?php echo e($student->gender); ?></td>
    
    <td><a href="<?php echo e(route('student.show' ,$student->id)); ?>">Show</a></td>
    <td><a href="<?php echo e(route('student.edit' ,$student->id)); ?>">Edit</a></td>
    <td>
        <form action="<?php echo e(route('student.destroy' ,$student->id)); ?>" method="POST" >
            <?php echo csrf_field(); ?> 
            <?php echo method_field('delete'); ?>
        <input type="submit" value="Delete">
</form></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <br>
    
    
</body>
</html>

   


<?php /**PATH D:\example-app\resources\views/student/index.blade.php ENDPATH**/ ?>