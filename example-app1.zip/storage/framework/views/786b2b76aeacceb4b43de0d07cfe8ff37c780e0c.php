<h1>index </h1>



<table border="1">
<?php $__currentLoopData = $employe; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $em): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr><td><?php echo e($em->id); ?></td>
<td><?php echo e($em->first_name); ?></td>
<td><?php echo e($em->last_name); ?></td>
<td><?php echo e($em->DOB); ?></td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table><?php /**PATH D:\example-app\resources\views/employe/index.blade.php ENDPATH**/ ?>