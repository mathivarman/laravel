<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<h1>Student Edit Details</h1>
<form action ="<?php echo e(route('student.update' ,$student->id)); ?>" method = "POST">

<?php echo csrf_field(); ?>
<?php echo method_field('PUT'); ?>
<label for="fname">First Name</label>
<input type ="text" name="fname" id="fname" value="<?php echo e($student->first_name); ?>">
<br><br>
<label for="lname">Last Name</label>
<input type ="text" name="lname" id="lname" value="<?php echo e($student->last_name); ?>">
<br>
<label for ="gender">Gender:</label>
<input type="radio" id="male" name="gender" value="male"<?php if($student-> gender=="male"){ 
        echo "checked";
       } ?>>
<label for="male">Male</label>
<input type="radio" id="female" name="gender" value="female"<?php if($student-> gender=="female"){ 
        echo "checked";
       } ?>>
<label for="female">Female</label>
<br><br>
<label for="grade">Select Grade</label>
<select name="grade" id="grade">
  <option value="2020">2020</option> 
  <option value="2021">2021</option>
  <option value="2022">2022</option>
</select>
<br><br>
<label for="address">Address</label>
<textarea name="address" id="address" cols="30" rows="5" ><?php echo e($student->address); ?></textarea>



<?php $sub=explode(',',$student->subject)?>
<br>
<label for="subject">Subjects</label><br>
<input type="checkbox" id="SFT" name="subject[]" value="SFT"<?php
    if(in_Array('SFT',$sub)){
       echo'checked';
    }
    ?> >
<label for="SFT"> SFT</label>
<input type="checkbox" id="ET" name="subject[]" value="ET"<?php
    if(in_Array('ET',$sub)){
       echo'checked';
    }
    ?> >
<label for="ET"> ET</label>
<input type="checkbox" id="ICT" name="subject[]" value="ICT"<?php
    if(in_Array('ICT',$sub)){
       echo'checked';
    }
    ?> >
<label for="ICT"> ICT</label>
<br><br>
<label for="birthday">Birthday:</label>
<input type="date" id="birthday" name="birthday"value="<?php echo e($student->date_of_birth); ?>">
<br><br>
<label for="email">Enter your email:</label>
<input type="email" id="email" name="email"value="<?php echo e($student->mail); ?>">
<br><br>
<label for="phone">Enter your phone number:</label>
<input type="tel" id="phone" name="phone" value="<?php echo e($student->phone); ?>">
<br><br>
<input type="submit" value="Save">


</form>
<br>
<a href="<?php echo e(route('student.index' )); ?>">show student list</a>
</body>
</html>




    
<?php /**PATH D:\example-app\resources\views/student/edit.blade.php ENDPATH**/ ?>