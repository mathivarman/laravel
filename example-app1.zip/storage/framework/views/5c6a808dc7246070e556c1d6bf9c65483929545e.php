<h1>create</h1>

<form action="<?php echo e(route('employe.store')); ?>" method="POST">
<?php echo csrf_field(); ?> 
<lable for="fname">first name </lable>
<input type="text" name="fname" id="fname" >
<br>
<lable for="lname">last name </lable>
<input type="text" name="lname" id="lname" >
<br>
<lable for="DOB">dob </lable>
<input type="date" name="DOB" id="DOB" >
<br>
<input type="submit" value="Save">
</form><?php /**PATH D:\example-app\resources\views/employe/create.blade.php ENDPATH**/ ?>