
<body style="background:<?php echo e($color); ?>">

<h1>gallery</h1>
<hr>


</body><?php /**PATH D:\example-app\resources\views/page/gallery.blade.php ENDPATH**/ ?>