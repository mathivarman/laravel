
<body style="background:<?php echo e($c); ?>">

myinfo
<hr>

<a href="<?php echo e(route('pages')); ?>">home</a><br>
</body><?php /**PATH D:\example-app\resources\views/page/myinfo.blade.php ENDPATH**/ ?>