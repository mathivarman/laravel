<h1>welcome</h1>
<hr>
<?php echo e($y); ?><?php /**PATH D:\example-app\resources\views/mv.blade.php ENDPATH**/ ?>