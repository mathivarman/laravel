<h1>welcome my home page </h1>
<br>
<body style="background:<?php echo e($color); ?>">

<?php /**PATH D:\example-app\resources\views/page/home.blade.php ENDPATH**/ ?>