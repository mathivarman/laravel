<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\EmployeController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|

*/

Route::resource('student',StudentController::class);
Route::resource('employe',EmployeController::class);







/*Route::get('/', function () {
     return view('welcome');
        })->name('home');
// Route::get('/', function () {
//     return view('mathi');
// });
 Route::get('/mathi', function () {
     return view('mathi');
 });
Route::get('/about/{n?}', function ($x=10) {
    return view('about')->with('y',$x);
    //return view('about')->withY($x);
    //return view('about';['y',$x]);
    //return view('about',array('y',$x));
    //$y=$x
     //return view('about',compact('y'));
    
})->where('n','[0-9]+');
// Route::get('/home', function () {
    // return "mv";
// });*/
/*Route::get('/page/{n?}', function ($page='home') {
     return view('page/'.$page)->with('page',$page);
});*/
/*Route::get('/', function () {
    return view('about');
});*/

/*Route::post('test', function () {
    return view('test');
});*/

/*Route::get('/page/{n?}/{c?}', function ($name="home",$color="red") {
    return view('page/'.$name,['n'=>$name,'c'=>$color]);
})->name('pages');*/

/*Route::get('/', function () {
    return view('page/aboutus');
});

Route::post('postpage',function(Request $request){
    $pname= $request->input('pname');
    $color= $request->input('color');

    return view('page/'.$pname,compact('pname','color'));
});



// Route::get('/', function () {
//     return view('mathi');/ });
Route::get('/1',[HomeController::class,"one"]);
Route::get('/2',[HomeController::class,"two"]);
Route::get('/3',[HomeController::class,"three"]);
Route::get('/4',[HomeController::class,"four"]);
Route::get('/5',[HomeController::class,"five"]);*/
